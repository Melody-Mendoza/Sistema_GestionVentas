/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;
/**
 *
 * @author Melody Nathalie Mendoza Jimenez
 * @author Josue Saul Lopez Trujillo
 */
import conexion.Conexion_Base;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Conexion_Login {

    public static String validarLogin(String correo, String contrasena) {
        String rolEncontrado = null;
        try {
            Connection con = new Conexion_Base().Conectar();
            String sql = """
                SELECT r.nombre_rol 
                FROM usuarios u 
                JOIN roles r ON u.id_rol = r.id_rol 
                WHERE u.correo = ? AND u.contrasena = ?
            """;
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, correo);
            ps.setString(2, contrasena);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                rolEncontrado = rs.getString("nombre_rol"); // administrador, cajero o cliente
            }
            con.close();
        } catch (Exception e) {
            System.out.println("❌ Error en login: " + e.getMessage());
        }
        return rolEncontrado;
    }

    // Método para obtener el ID del usuario logueado
    public static int obtenerIdUsuario(String correo, String contrasena) {
        int idUsuario = -1;
        try {
            Connection con = new Conexion_Base().Conectar();
            String sql = "SELECT id FROM usuarios WHERE correo = ? AND contrasena = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, correo);
            ps.setString(2, contrasena);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                idUsuario = rs.getInt("id");
            }
            con.close();
        } catch (Exception e) {
            System.out.println("❌ Error al obtener ID de usuario: " + e.getMessage());
        }
        return idUsuario;
    }
}

