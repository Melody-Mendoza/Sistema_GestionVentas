/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 * Clase encargada de conectar a la base de datos mini_super.
 *
 * @author Melody Nathalie Mendoza Jimenez
 * @author Josue Saul Lopez Trujillo
 */
public class Conexion_Base {

    String bd = "mini_super";
    String url = "jdbc:mysql://127.0.0.1:3306/";
    String user = "root";
    String password = "melody1905";
    String driver = "com.mysql.cj.jdbc.Driver";
    Connection cx;

    public Conexion_Base() {

    }

    public Connection Conectar() {
        try {
            Class.forName(driver);
            cx = DriverManager.getConnection(url + bd, user, password);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Conexion_Base.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cx;
    }

    public void Desconectar() {
        try {
            cx.close();
        } catch (SQLException ex) {
            Logger.getLogger(Conexion_Base.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String args[]) {
        Conexion_Base CB = new Conexion_Base();
        CB.Conectar();
    }

}
