/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyecto_bd;
/**
 *
 * @author Melody Nathalie Mendoza Jimenez
 * @author Josue Saul Lopez Trujillo
 */
import conexion.Conexion_Base;
import conexion.CorreoPDF;
import java.awt.Color;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Carrito extends javax.swing.JFrame {

    private int idUsuario;
    Connection con;
    DefaultTableModel modeloProductos;
    DefaultTableModel modeloCarrito;
    double total = 0.0;
    private int paginaActual = 1;
    private final int productosPorPagina = 10;
    private boolean pagoValidado = false;

    public Carrito() {
        initComponents();
        con = new Conexion_Base().Conectar();
        configurarTablas();
        cargarProductosPaginados();
        //cargarProductos();
        txtBusqueda.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String texto = txtBusqueda.getText();
                buscarProductosPorNombre(texto);
            }
        });
        cmbTipoPago.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tipo = (String) cmbTipoPago.getSelectedItem();

                if ("Efectivo".equals(tipo)) {
                    txtCantidadPagada.setEnabled(true);
                    txtNumCuenta.setEnabled(false);
                    txtNip.setEnabled(false);
                    txtNumCuenta.setText("");
                    txtNip.setText("");
                    lblCambio.setText("");
                } else if ("Tarjeta".equals(tipo)) {
                    txtCantidadPagada.setEnabled(false);
                    txtNumCuenta.setEnabled(true);
                    txtNip.setEnabled(true);
                    txtCantidadPagada.setText("");
                    lblCambio.setText("0.00");
                }
            }
        });
        txtCantidadPagada.setEnabled(false);
        txtNumCuenta.setEnabled(false);
        txtNip.setEnabled(false);
        lblCambio.setText("");
    }

    public Carrito(int idUsuario) {
        this.idUsuario = idUsuario;
        initComponents();
        con = new Conexion_Base().Conectar();
        this.modeloProductos = (DefaultTableModel) tblProductos.getModel();
        modeloCarrito = new DefaultTableModel(new Object[]{"ID", "NOMBRE", "PRECIO", "CANTIDAD", "SUBTOTAL"}, 0);
        tblCarrito.setModel(modeloCarrito);
        cargarProductosPaginados();
        txtBusqueda.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String texto = txtBusqueda.getText();
                buscarProductosPorNombre(texto);
            }
        });
        cmbTipoPago.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tipo = (String) cmbTipoPago.getSelectedItem();
                if ("Efectivo".equalsIgnoreCase(tipo)) {
                    txtCantidadPagada.setEnabled(true);
                    txtNumCuenta.setEnabled(false);
                    txtNip.setEnabled(false);
                    txtNumCuenta.setText("");
                    txtNip.setText("");
                    lblCambio.setText("");
                } else if ("Tarjeta".equalsIgnoreCase(tipo)) {
                    txtCantidadPagada.setEnabled(false);
                    txtNumCuenta.setEnabled(true);
                    txtNip.setEnabled(true);
                    txtCantidadPagada.setText("");
                    lblCambio.setText("0.00");
                } else {
                    txtCantidadPagada.setEnabled(false);
                    txtNumCuenta.setEnabled(false);
                    txtNip.setEnabled(false);
                    txtCantidadPagada.setText("");
                    txtNumCuenta.setText("");
                    txtNip.setText("");
                    lblCambio.setText("");
                }
            }
        });

// Estado inicial
        cmbTipoPago.setSelectedIndex(0);
        txtCantidadPagada.setEnabled(false);
        txtNumCuenta.setEnabled(false);
        txtNip.setEnabled(false);
        lblCambio.setText("");

    }
    private void configurarTablas() {
        modeloProductos = new DefaultTableModel(new Object[]{"ID", "NOMBRE", "DESCRIPCION", "PRECIO", "STOCK", "CATEGORIA"}, 0);
        tblProductos.setModel(modeloProductos);

        modeloCarrito = new DefaultTableModel(new Object[]{"ID", "NOMBRE", "PRECIO", "CANTIDAD", "SUBTOTAL"}, 0);
        tblCarrito.setModel(modeloCarrito);
    }

    private void cargarProductos() {
        try {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM productos");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                modeloProductos.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("descripcion"),
                    rs.getDouble("precio"),
                    rs.getInt("stock"),
                    rs.getString("categoria")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar productos: " + e);
        }
    }

    private void agregarAlCarrito() {
        int fila = tblProductos.getSelectedRow();
        if (fila >= 0) {
            int id = (int) modeloProductos.getValueAt(fila, 0);
            String nombre = (String) modeloProductos.getValueAt(fila, 1);
            double precio = (double) modeloProductos.getValueAt(fila, 3);
            int stock = (int) modeloProductos.getValueAt(fila, 4);

            int cantidadIngresada;
            try {
                cantidadIngresada = Integer.parseInt(txtCantidad.getText());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Ingrese una cantidad válida.");
                return;
            }

            if (cantidadIngresada <= 0) {
                JOptionPane.showMessageDialog(this, "Cantidad inválida.");
                return;
            }

            // Verificar si ya está en el carrito y cuántas unidades hay
            int cantidadYaEnCarrito = 0;
            for (int i = 0; i < modeloCarrito.getRowCount(); i++) {
                int idEnCarrito = (int) modeloCarrito.getValueAt(i, 0);
                if (id == idEnCarrito) {
                    cantidadYaEnCarrito = (int) modeloCarrito.getValueAt(i, 3);
                    break;
                }
            }

            int cantidadTotal = cantidadYaEnCarrito + cantidadIngresada;

            //  Validar contra el stock total
            if (cantidadTotal > stock) {
                JOptionPane.showMessageDialog(this, "No puedes agregar más de " + stock + " unidades. Ya hay " + cantidadYaEnCarrito + " en el carrito.");
                return;
            }

            // Agregar al carrito o actualizar cantidad
            boolean productoExistente = false;
            for (int i = 0; i < modeloCarrito.getRowCount(); i++) {
                if ((int) modeloCarrito.getValueAt(i, 0) == id) {
                    int nuevaCantidad = cantidadYaEnCarrito + cantidadIngresada;
                    double nuevoSubtotal = nuevaCantidad * precio;
                    modeloCarrito.setValueAt(nuevaCantidad, i, 3);
                    modeloCarrito.setValueAt(nuevoSubtotal, i, 4);
                    productoExistente = true;
                    break;
                }
            }

            if (!productoExistente) {
                double subtotal = precio * cantidadIngresada;
                modeloCarrito.addRow(new Object[]{id, nombre, precio, cantidadIngresada, subtotal});
            }

            total += precio * cantidadIngresada;
            lblTotal.setText(String.format("%.2f", total));
            txtCantidad.setText(""); // limpiar campo
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un producto.");
        }
    }
    private void confirmarVenta(int idCajero) {
        try {
            String nombreCliente = txtNombreCliente.getText().trim();
            String correoCliente = txtCorreoCliente.getText().trim();
            if (correoCliente.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Debe ingresar al menos el correo del cliente.", "Campo requerido", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (modeloCarrito.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "El carrito está vacío.", "Sin productos", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // String tipoPago = (String) cmbTipoPago.getSelectedItem();
            //if (tipoPago == null || tipoPago.isEmpty()) {
            //JOptionPane.showMessageDialog(this, "Seleccione un método de pago.", "Error", JOptionPane.ERROR_MESSAGE);
            // return;
            //}
            String tipoPago = (String) cmbTipoPago.getSelectedItem();
            if (cmbTipoPago.getSelectedIndex() == -1 || tipoPago == null || tipoPago.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Seleccione un método de pago antes de continuar.", "Método de pago requerido", JOptionPane.WARNING_MESSAGE);
                return;
            }


        if ("Efectivo".equalsIgnoreCase(tipoPago)) {
            String textoEntregado = txtCantidadPagada.getText().trim();
            if (textoEntregado.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese la cantidad entregada.", "Falta dato", JOptionPane.WARNING_MESSAGE);
                return;
            }

            double entregado;
            try {
                entregado = Double.parseDouble(textoEntregado);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Cantidad no válida.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (entregado < total) {
                JOptionPane.showMessageDialog(this, "La cantidad entregada es menor al total.", "Dinero insuficiente", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double cambio = entregado - total;
            lblCambio.setText(String.format("%.2f", cambio));
            JOptionPane.showMessageDialog(this, "Pago en efectivo aceptado.\nCambio: $" + cambio);

            pagoValidado = true;

        } else if ("Tarjeta".equalsIgnoreCase(tipoPago)) {
            String cuenta = txtNumCuenta.getText().trim();
            String nip = new String(txtNip.getPassword()).trim();

            if (cuenta.length() < 16) {
                JOptionPane.showMessageDialog(this, "Ingrese un número de cuenta válido.", "Cuenta inválida", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (nip.length() < 4) {
                JOptionPane.showMessageDialog(this, "Ingrese un NIP válido.", "NIP inválido", JOptionPane.WARNING_MESSAGE);
                return;
            }

            lblCambio.setText("0.00");
            JOptionPane.showMessageDialog(this, "Pago con tarjeta simulado.\nCuenta terminada en: " + cuenta.substring(cuenta.length() - 4));

            pagoValidado = true;
        }
        
            Conexion_Base conexion = new Conexion_Base();
            Connection con = conexion.Conectar();

            // Verificar si el cliente ya existe por correo
            int idCliente = buscarClientePorCorreo(correoCliente);
            if (idCliente == -1) {
                // Es cliente nuevo, validar nombre
                if (nombreCliente.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Debe ingresar el nombre si es un cliente nuevo.", "Nombre requerido", JOptionPane.WARNING_MESSAGE);
                    return;
                }

                // Registrar nuevo cliente
                idCliente = registrarCliente(nombreCliente, correoCliente);
                if (idCliente == -1) {
                    JOptionPane.showMessageDialog(this, "No se pudo registrar al cliente.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } else {
                // Cliente ya registrado, obtener su nombre desde la base de datos
                nombreCliente = obtenerNombreClientePorCorreo(correoCliente);
            }
            // Insertar venta
            PreparedStatement psVenta = con.prepareStatement(
                    "INSERT INTO ventas (id_usuario, id_cliente, total) VALUES (?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS
            );
            psVenta.setInt(1, idCajero);
            psVenta.setInt(2, idCliente);
            psVenta.setDouble(3, total);
            psVenta.executeUpdate();

            ResultSet rs = psVenta.getGeneratedKeys();
            int idVenta = 0;
            if (rs.next()) {
                idVenta = rs.getInt(1);
            }

            // Insertar detalle y actualizar stock
            for (int i = 0; i < modeloCarrito.getRowCount(); i++) {
                int idProducto = (int) modeloCarrito.getValueAt(i, 0);
                int cantidad = (int) modeloCarrito.getValueAt(i, 3);
                double subtotal = (double) modeloCarrito.getValueAt(i, 4);

                PreparedStatement psDetalle = con.prepareStatement(
                        "INSERT INTO detalle_venta (id_venta, id_producto, cantidad, subtotal) VALUES (?, ?, ?, ?)"
                );
                psDetalle.setInt(1, idVenta);
                psDetalle.setInt(2, idProducto);
                psDetalle.setInt(3, cantidad);
                psDetalle.setDouble(4, subtotal);
                psDetalle.executeUpdate();

                // Verificación de stock mínima: evitar stock negativo
                PreparedStatement psStockCheck = con.prepareStatement("SELECT stock FROM productos WHERE id = ?");
                psStockCheck.setInt(1, idProducto);
                ResultSet rsStock = psStockCheck.executeQuery();
                if (rsStock.next() && rsStock.getInt("stock") < cantidad) {
                    JOptionPane.showMessageDialog(this, "Stock insuficiente para producto ID: " + idProducto, "Error de stock", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Actualizar stock
                PreparedStatement psStock = con.prepareStatement(
                        "UPDATE productos SET stock = stock - ? WHERE id = ?"
                );
                psStock.setInt(1, cantidad);
                psStock.setInt(2, idProducto);
                psStock.executeUpdate();
            }

            // Generar PDF
            CorreoPDF pdf = new CorreoPDF();
            String[][] carritoDatos = obtenerDatosCarrito();
            pdf.generarPDFVenta(nombreCliente, correoCliente, carritoDatos, total, cmbTipoPago.getSelectedItem().toString());

            JOptionPane.showMessageDialog(this, "Venta realizada correctamente.");
            modeloCarrito.setRowCount(0);
            total = 0;
            lblTotal.setText("0.00");
            modeloProductos.setRowCount(0);
            txtNombreCliente.setText("");
            txtCorreoCliente.setText("");
            cmbTipoPago.setSelectedIndex(0);
            txtCantidadPagada.setText("");
            txtNumCuenta.setText("");
            txtNip.setText("");
            lblCambio.setText("");

// Deshabilitar campos
            txtCantidadPagada.setEnabled(false);
            txtNumCuenta.setEnabled(false);
            txtNip.setEnabled(false);

// Reiniciar validación
            pagoValidado = false;
            cargarProductos();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al registrar la venta: " + e.getMessage(), "Error SQL", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }


    public String obtenerNombreClientePorCorreo(String correo) {
        String nombre = "";
        Conexion_Base conexion = new Conexion_Base();
        Connection con = conexion.Conectar();

        String sql = "SELECT nombre FROM clientes WHERE correo = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, correo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                nombre = rs.getString("nombre");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return nombre;
    }


    private void buscarProductosPorNombre(String nombre) {
        modeloProductos.setRowCount(0); // Limpiar tabla

        String sql = "SELECT * FROM productos WHERE nombre LIKE ?";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, "%" + nombre + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                modeloProductos.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("descripcion"),
                    rs.getDouble("precio"),
                    rs.getInt("stock"),
                    rs.getString("categoria")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al buscar productos: " + e.getMessage());
        }
    }


    private int obtenerIdUsuarioLogueado() {
        return idUsuario;
    }

    public int buscarClientePorCorreo(String correo) {
        int idCliente = -1;
        Conexion_Base conexion = new Conexion_Base();
        Connection con = conexion.Conectar();
        String sql = "SELECT id FROM clientes WHERE correo = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, correo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                idCliente = rs.getInt("id");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return idCliente;
    }
    public int registrarCliente(String nombre, String correo) {
        int idCliente = -1;
        Conexion_Base conexion = new Conexion_Base();
        Connection con = conexion.Conectar();

        String sql = "INSERT INTO clientes (nombre, correo) VALUES (?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, nombre);
            ps.setString(2, correo);
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                idCliente = rs.getInt(1); // ID generado
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return idCliente;
    }
    private void actualizarPaginacion(int totalProductos, int productosPorPagina) {
        panelPaginacion.removeAll(); // Limpiar paginación anterior
        int totalPaginas = (int) Math.ceil((double) totalProductos / productosPorPagina);
        // Botón « anterior
        JButton btnAnterior = new JButton("«");
        btnAnterior.addActionListener(e -> {
            if (paginaActual > 1) {
                paginaActual--;
                cargarProductosPaginados();
                actualizarPaginacion(totalProductos, productosPorPagina);
            }
        });
        panelPaginacion.add(btnAnterior);
        // Botones de página
        for (int i = 1; i <= totalPaginas; i++) {
            JButton btnPagina = new JButton(String.valueOf(i));
            if (i == paginaActual) {
                btnPagina.setBackground(Color.BLUE);
                btnPagina.setForeground(Color.WHITE);
            }
            int pagina = i;
            btnPagina.addActionListener(e -> {
                paginaActual = pagina;
                cargarProductosPaginados();
                actualizarPaginacion(totalProductos, productosPorPagina);
            });
            panelPaginacion.add(btnPagina);
        }
        // Botón siguiente »
        JButton btnSiguiente = new JButton("»");
        btnSiguiente.addActionListener(e -> {
            if (paginaActual < totalPaginas) {
                paginaActual++;
                cargarProductosPaginados();
                actualizarPaginacion(totalProductos, productosPorPagina);
            }
        });
        panelPaginacion.add(btnSiguiente);

        panelPaginacion.revalidate();
        panelPaginacion.repaint();
    }
    private void cargarProductosPaginados() {
        int offset = (paginaActual - 1) * productosPorPagina;
        Conexion_Base conexion = new Conexion_Base();
        Connection con = conexion.Conectar();
        try {
            // Calcular total de productos
            String sqlCount = "SELECT COUNT(*) FROM productos";
            PreparedStatement psCount = con.prepareStatement(sqlCount);
            ResultSet rsCount = psCount.executeQuery();
            int totalProductos = 0;
            if (rsCount.next()) {
                totalProductos = rsCount.getInt(1);
            }
            // Cargar productos de la página actual
            String sql = "SELECT * FROM productos ORDER BY id LIMIT ? OFFSET ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, productosPorPagina);
            ps.setInt(2, offset);
            ResultSet rs = ps.executeQuery();
            modeloProductos.setRowCount(0); // Limpiar tabla
            while (rs.next()) {
                Object[] fila = {
                    rs.getInt("id"),
                    rs.getString("nombre"),
                    rs.getString("descripcion"),
                    rs.getDouble("precio"),
                    rs.getInt("stock"),
                    rs.getString("categoria")
                };
                modeloProductos.addRow(fila);
            }
            // Actualizar la paginación
            actualizarPaginacion(totalProductos, productosPorPagina);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private void aceptarPago() {
        String tipoPago = (String) cmbTipoPago.getSelectedItem();

        if (tipoPago == null || tipoPago.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Seleccione un método de pago.");
            return;
        }

        if (tipoPago.equals("Efectivo")) {
            String cantidadTxt = txtCantidadPagada.getText().trim();
            if (cantidadTxt.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese la cantidad entregada.");
                return;
            }

            try {
                double cantidadEntregada = Double.parseDouble(cantidadTxt);
                if (cantidadEntregada < total) {
                    JOptionPane.showMessageDialog(this, "La cantidad es insuficiente.");
                    return;
                }

                double cambio = cantidadEntregada - total;
                lblCambio.setText(String.format("%.2f", cambio));
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Ingrese una cantidad válida.");
            }

        } else if (tipoPago.equals("Tarjeta")) {
            String numCuenta = txtNumCuenta.getText().trim();
            String nip = new String(txtNip.getPassword()).trim();

            if (numCuenta.isEmpty() || nip.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Complete los datos de la tarjeta.");
                return;
            }

            if (numCuenta.length() < 4 || nip.length() < 4) {
                JOptionPane.showMessageDialog(this, "Datos de tarjeta inválidos.");
                return;
            }

            lblCambio.setText("0.00"); // No hay cambio con tarjeta
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblProductos = new javax.swing.JTable();
        txtCantidad = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        txtBusqueda = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        panelPaginacion = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblCarrito = new javax.swing.JTable();
        lblTotal = new javax.swing.JLabel();
        btnConfirmar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btnEliminar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txtNombreCliente = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtCorreoCliente = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        cmbTipoPago = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtCantidadPagada = new javax.swing.JTextField();
        lblCambio = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtNumCuenta = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtNip = new javax.swing.JPasswordField();
        lblSeg = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("CARRITO");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setOpaque(false);

        tblProductos.setBackground(new java.awt.Color(212, 129, 210));
        tblProductos.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        tblProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "NOMBRE", "DESCRIPCION", "PRECIO", "STOCK", "CATEGORIA"
            }
        ));
        jScrollPane1.setViewportView(tblProductos);

        txtCantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantidadActionPerformed(evt);
            }
        });

        btnAgregar.setBackground(new java.awt.Color(27, 158, 20));
        btnAgregar.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnAgregar.setForeground(new java.awt.Color(255, 255, 255));
        btnAgregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/carrito-de-compras.png"))); // NOI18N
        btnAgregar.setText("AGREGAR");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        jLabel1.setBackground(new java.awt.Color(204, 204, 204));
        jLabel1.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("CANTIDAD:");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/archivo-de-busqueda.png"))); // NOI18N

        panelPaginacion.setOpaque(false);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(271, 271, 271)
                        .addComponent(btnAgregar))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 695, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(txtBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 35, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(149, 149, 149)
                .addComponent(panelPaginacion, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(panelPaginacion, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAgregar))
                .addContainerGap())
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 730, 360));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Stencil", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(32, 114, 95));
        jLabel3.setText("MINI SÚPER  \"DESPENSA DEL CORAZÓN\"");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 20, 700, 60));

        jPanel2.setBackground(new java.awt.Color(212, 129, 210));

        tblCarrito.setBackground(new java.awt.Color(212, 129, 210));
        tblCarrito.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        tblCarrito.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "NOMBRE", "PRECIO", "CANTIDAD", "SUBTOTAL"
            }
        ));
        jScrollPane2.setViewportView(tblCarrito);

        lblTotal.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTotal.setForeground(new java.awt.Color(255, 0, 0));
        lblTotal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        btnConfirmar.setBackground(new java.awt.Color(27, 158, 20));
        btnConfirmar.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        btnConfirmar.setForeground(new java.awt.Color(255, 255, 255));
        btnConfirmar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/checked.png"))); // NOI18N
        btnConfirmar.setText("CONFIRMAR VENTA");
        btnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 0, 0));
        jLabel5.setText("TOTAL:");

        btnEliminar.setBackground(new java.awt.Color(255, 0, 0));
        btnEliminar.setFont(new java.awt.Font("Arial Black", 1, 10)); // NOI18N
        btnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        btnEliminar.setText("QUITAR DEL CARRITO");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 621, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                                .addComponent(btnConfirmar)))
                        .addContainerGap())
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(btnEliminar)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(btnEliminar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(btnConfirmar)
                .addGap(16, 16, 16))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 500, -1, 200));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/carro-de-la-carretilla.png"))); // NOI18N
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 40, 40, 30));

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 10)); // NOI18N
        jButton1.setForeground(new java.awt.Color(75, 0, 130));
        jButton1.setText("REGRESAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, -1));

        jLabel7.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("NOMBRE CLIENTE:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, -1, -1));

        txtNombreCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreClienteActionPerformed(evt);
            }
        });
        getContentPane().add(txtNombreCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 90, 161, -1));

        jLabel6.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("CORREO CLIENTE:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 90, -1, -1));
        getContentPane().add(txtCorreoCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 90, 155, -1));

        jPanel3.setBackground(new java.awt.Color(212, 129, 210));

        cmbTipoPago.setBackground(new java.awt.Color(140, 229, 164));
        cmbTipoPago.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        cmbTipoPago.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "EFECTIVO", "TARJETA" }));
        cmbTipoPago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbTipoPagoActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/billetera.png"))); // NOI18N
        jLabel9.setText("TIPO DE PAGO");

        jLabel10.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("MÉTODO DE PAGO:");

        jLabel11.setFont(new java.awt.Font("Arial Black", 1, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("CANTIDAD ENTREGADA:");

        txtCantidadPagada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCantidadPagadaActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Constantia", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 153));
        jLabel13.setText("CAMBIO:");

        jLabel14.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tarjeta-de-credito.png"))); // NOI18N
        jLabel14.setText("Núm. Cuenta:");

        txtNumCuenta.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        txtNumCuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNumCuentaActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("NIP:");

        txtNip.setText("jPasswordField1");

        lblSeg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cerrar.png"))); // NOI18N
        lblSeg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblSegMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblSegMouseReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cmbTipoPago, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(39, 39, 39))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtCantidadPagada, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblCambio, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(67, 67, 67))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtNip, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(18, 18, 18)
                                .addComponent(lblSeg, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtNumCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbTipoPago, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(26, 26, 26)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txtCantidadPagada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblCambio, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtNumCuenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblSeg))
                .addGap(54, 54, 54))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 120, 300, 320));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Carrito2.jpg"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -50, 1060, 790));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCantidadActionPerformed

    private void btnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarActionPerformed
        // TODO add your handling code here:
        int idCajero = obtenerIdUsuarioLogueado(); // Método para recuperar el ID del cajero
        
        confirmarVenta(idCajero);
    }//GEN-LAST:event_btnConfirmarActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        // TODO add your handling code here:
        agregarAlCarrito();
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void txtNombreClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreClienteActionPerformed
    public String[][] obtenerDatosCarrito() {
        int filas = modeloCarrito.getRowCount();
        String[][] datos = new String[filas][5]; // ID, Producto, Cantidad, Precio, Subtotal

        for (int i = 0; i < filas; i++) {
            datos[i][0] = modeloCarrito.getValueAt(i, 0).toString(); // ID
            datos[i][1] = modeloCarrito.getValueAt(i, 1).toString(); // Producto
            datos[i][2] = modeloCarrito.getValueAt(i, 3).toString(); // Cantidad
            datos[i][3] = modeloCarrito.getValueAt(i, 2).toString(); // Precio Unitario
            datos[i][4] = modeloCarrito.getValueAt(i, 4).toString(); // Subtotal
        }
        return datos;
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Login ventanaLogin = new Login();  // Instancia
        ventanaLogin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // TODO add your handling code here:
        int fila = tblCarrito.getSelectedRow();
        if (fila >= 0) {
            double subtotal = (double) modeloCarrito.getValueAt(fila, 4);
            total -= subtotal;
            lblTotal.setText(String.format("%.2f", total));
            modeloCarrito.removeRow(fila);
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un producto del carrito para eliminar.");
        }

    }//GEN-LAST:event_btnEliminarActionPerformed

    private void txtCantidadPagadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCantidadPagadaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCantidadPagadaActionPerformed

    private void txtNumCuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNumCuentaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNumCuentaActionPerformed

    private void cmbTipoPagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbTipoPagoActionPerformed
        // TODO add your handling code here:
        String tipo = (String) cmbTipoPago.getSelectedItem();

        if ("Efectivo".equals(tipo)) {
            txtCantidadPagada.setEnabled(true);
            txtNumCuenta.setEnabled(false);
            txtNip.setEnabled(false);
            txtNumCuenta.setText("");
            txtNip.setText("");
            lblCambio.setText(""); // Reiniciar cambio

        } else if ("Tarjeta".equals(tipo)) {
            txtCantidadPagada.setEnabled(false);
            txtNumCuenta.setEnabled(true);
            txtNip.setEnabled(true);
            txtCantidadPagada.setText("");
            lblCambio.setText("0.00"); // No hay cambio
        }

    }//GEN-LAST:event_cmbTipoPagoActionPerformed

    private void lblSegMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSegMousePressed
        // TODO add your handling code here:
        txtNip.setEchoChar((char)0);
    }//GEN-LAST:event_lblSegMousePressed

    private void lblSegMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblSegMouseReleased
        // TODO add your handling code here:
        txtNip.setEchoChar('*');
    }//GEN-LAST:event_lblSegMouseReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Carrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Carrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Carrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Carrito.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Carrito().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnConfirmar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JComboBox<String> cmbTipoPago;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblCambio;
    private javax.swing.JLabel lblSeg;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JPanel panelPaginacion;
    private javax.swing.JTable tblCarrito;
    private javax.swing.JTable tblProductos;
    private javax.swing.JTextField txtBusqueda;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtCantidadPagada;
    private javax.swing.JTextField txtCorreoCliente;
    private javax.swing.JPasswordField txtNip;
    private javax.swing.JTextField txtNombreCliente;
    private javax.swing.JTextField txtNumCuenta;
    // End of variables declaration//GEN-END:variables
}
