/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexion;
/**
 *
 * @author Melody Nathalie Mendoza Jimenez
 * @author Josue Saul Lopez Trujillo
 */
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;

public class CorreoPDF {

    public void enviarRegistro(String nombre, String correoDestino, String contrasena, String rol) {
        try {
            String nombreArchivo = "Bienvenida_" + nombre.replaceAll("\\s+", "") + ".pdf";
            generarPDF(nombre, correoDestino, contrasena, rol, nombreArchivo);
            enviarCorreo(nombreArchivo, correoDestino);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void generarPDF(String nombre, String correo, String contrasena, String rol, String nombreArchivo) throws Exception {
        Document document = new Document();
        PdfWriter.getInstance(document, new FileOutputStream(nombreArchivo));
        document.open();

        // Logo
        Image logo = Image.getInstance("src/img/LogoAbarrotes2.png");
        logo.scaleToFit(120, 120);
        logo.setAlignment(Image.ALIGN_CENTER);
        document.add(logo);

        // Fuente principal
        Font fontTitulo = new Font(Font.FontFamily.HELVETICA, 22, Font.BOLD, new BaseColor(30, 30, 30));
        Font fontSubtitulo = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, new BaseColor(60, 60, 60));
        Font fontTexto = new Font(Font.FontFamily.HELVETICA, 12, Font.NORMAL, BaseColor.BLACK);

        // Título
        Paragraph titulo = new Paragraph("MINI SUPER \"DESPENSA DEL CORAZÓN\"", fontTitulo);
        titulo.setAlignment(Element.ALIGN_CENTER);
        titulo.setSpacingBefore(10);
        titulo.setSpacingAfter(20);
        document.add(titulo);

        // Subtítulo
        Paragraph subtitulo = new Paragraph("Confirmación de Registro", fontSubtitulo);
        subtitulo.setAlignment(Element.ALIGN_CENTER);
        subtitulo.setSpacingAfter(20);
        document.add(subtitulo);

        // Contenido
        Paragraph contenido = new Paragraph();
        contenido.setAlignment(Element.ALIGN_LEFT);
        contenido.setFont(fontTexto);
        contenido.add("Hola " + nombre + ",\n\n");
        contenido.add("Gracias por registrarte en nuestro sistema. A continuación se detallan tus datos de acceso:\n\n");
        contenido.add("📧 Correo electrónico: " + correo + "\n");
        contenido.add("🔒 Contraseña: " + contrasena + "\n\n");
        contenido.add("🔑 Rol asignado: " + rol + "\n");
        contenido.add("📌 Si tienes dudas o necesitas asistencia, no dudes en contactarnos.\n\n");
        contenido.add("¡Gracias por confiar en nosotros!\n");
        contenido.add("Atentamente,\n");
        contenido.add("Equipo de \"DESPENSA DEL CORAZÓN\"");
        contenido.setSpacingAfter(20);
        document.add(contenido);

        // Pie de página
        Paragraph pie = new Paragraph("Este documento fue generado automáticamente. No responder a este correo.", new Font(Font.FontFamily.HELVETICA, 10, Font.ITALIC, BaseColor.GRAY));
        pie.setAlignment(Element.ALIGN_CENTER);
        pie.setSpacingBefore(30);
        document.add(pie);

        document.close();
    }

    private void enviarCorreo(String rutaPDF, String destinatario) throws MessagingException {
        final String remitente = "despensadelcorazon@gmail.com";
        final String contraseña = "zhhp frus cyub lqwi"; // Contraseña de aplicación

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, contraseña);
            }
        });

        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(remitente));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
        message.setSubject("🎉 Bienvenido a la DESPENSA DEL CORAZÓN");

        // Cuerpo del correo
        BodyPart mensajeTexto = new MimeBodyPart();
        mensajeTexto.setText("Hola, adjuntamos un archivo PDF generado por el sistema. Gracias.");

        // PDF adjunto
        MimeBodyPart adjunto = new MimeBodyPart();
        DataSource source = new FileDataSource(new File(rutaPDF));
        adjunto.setDataHandler(new DataHandler(source));
        adjunto.setFileName(rutaPDF);

        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(mensajeTexto);
        multipart.addBodyPart(adjunto);

        message.setContent(multipart);
        Transport.send(message);

        System.out.println("✅ Correo enviado exitosamente a " + destinatario);
    }

    public void generarPDFVenta(String nombreCliente, String correo, String[][] carrito, double total, String tipoPago) {
        try {
            String nombreArchivo = "TicketVenta_" + nombreCliente.replaceAll("\\s+", "") + ".pdf";

            Document document = new Document(PageSize.A6); // Ticket pequeño
            PdfWriter.getInstance(document, new FileOutputStream(nombreArchivo));
            document.open();

            // Logo
            Image logo = Image.getInstance("src/img/LogoAbarrotes2.png");
            logo.scaleToFit(80, 80);
            logo.setAlignment(Image.ALIGN_CENTER);
            document.add(logo);

            // Fuentes
            Font fontTitulo = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD, new BaseColor(50, 50, 50));
            Font fontNormal = new Font(Font.FontFamily.HELVETICA, 8, Font.NORMAL);
            Font fontNegrita = new Font(Font.FontFamily.HELVETICA, 8, Font.BOLD);
            Font fontPie = new Font(Font.FontFamily.HELVETICA, 7, Font.ITALIC, BaseColor.GRAY);

            // Título
            Paragraph titulo = new Paragraph("MINI SUPER \"DESPENSA DEL CORAZÓN\"", fontTitulo);
            titulo.setAlignment(Element.ALIGN_CENTER);
            titulo.setSpacingAfter(10);
            document.add(titulo);

            Paragraph cliente = new Paragraph("Cliente: " + nombreCliente, fontNormal);
            cliente.setAlignment(Element.ALIGN_LEFT);
            cliente.setSpacingAfter(5);
            document.add(cliente);

            Paragraph correoP = new Paragraph("Correo: " + correo, fontNormal);
            correoP.setAlignment(Element.ALIGN_LEFT);
            correoP.setSpacingAfter(10);
            document.add(correoP);

            // Tabla
            PdfPTable tabla = new PdfPTable(5); // ID, Nombre, Cantidad, Subtotal
            tabla.setWidths(new int[]{1, 3, 1, 2, 2});
            tabla.setWidthPercentage(100);

            // Encabezados
            String[] encabezados = {"ID", "Producto", "Cant.", "Precio", "Subtotal"};
            for (String enc : encabezados) {
                PdfPCell celdaEnc = new PdfPCell(new Phrase(enc, fontNegrita));
                celdaEnc.setHorizontalAlignment(Element.ALIGN_CENTER);
                celdaEnc.setBackgroundColor(new BaseColor(230, 230, 250));
                tabla.addCell(celdaEnc);
            }

            for (String[] fila : carrito) {
                for (String valor : fila) {
                    PdfPCell celda = new PdfPCell(new Phrase(valor, fontNormal));
                    celda.setHorizontalAlignment(Element.ALIGN_CENTER);
                    tabla.addCell(celda);
                }
            }
            document.add(tabla);

            // Total
            Paragraph totalP = new Paragraph("TOTAL: $" + String.format("%.2f", total), fontNegrita);
            totalP.setAlignment(Element.ALIGN_RIGHT);
            totalP.setSpacingBefore(10);
            document.add(totalP);
            Paragraph metodoPago = new Paragraph("Método de pago: " + tipoPago, fontNormal);
            metodoPago.setAlignment(Element.ALIGN_LEFT);
            metodoPago.setSpacingBefore(5);
            document.add(metodoPago);

            // Pie
            Paragraph gracias = new Paragraph("¡Gracias por tu compra!", fontNormal);
            gracias.setAlignment(Element.ALIGN_CENTER);
            gracias.setSpacingBefore(20);
            document.add(gracias);

            Paragraph pie = new Paragraph("Este ticket fue generado automáticamente.", fontPie);
            pie.setAlignment(Element.ALIGN_CENTER);
            pie.setSpacingBefore(5);
            document.add(pie);

            document.close();

            // Si quieres enviar por correo:
            enviarCorreo(nombreArchivo, correo);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
